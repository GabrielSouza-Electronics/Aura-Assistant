#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Borda ciano com glow - Aura Assistant.

Um anel na borda do display redondo, com o brilho decaindo para DENTRO.
O glow nao pode vazar para fora: ali nao ha pixel nenhum, e o vidro corta
exatamente no raio 240.

Saida: rim/rim.png  (480x480, L8_ARGB8888)
"""

import os
import numpy as np
from scipy import ndimage
from PIL import Image

import os as _os
_HERE = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))

OUT = _os.path.join(_HERE, "rim")

SIZE = 480
R_OUT = 239.0          # raio externo: 1 px de folga da borda fisica
LINE_W = 2.2           # espessura da linha nitida
GLOW_IN = 10.0         # ate onde o glow entra, em px
SS = 3                 # supersampling do anel

C_LOW, C_MID, C_HIGH = (6, 60, 110), (40, 190, 240), (215, 252, 255)


def build():
    n = SIZE * SS
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float32)
    d = np.sqrt((xx - n / 2) ** 2 + (yy - n / 2) ** 2) / SS   # em px finais

    # linha nitida na borda
    line = np.clip(1.0 - np.abs(d - (R_OUT - LINE_W / 2)) / (LINE_W / 2), 0, 1) ** 0.7

    # glow decaindo PARA DENTRO: maximo na borda, zero a GLOW_IN px dela.
    # (dentro = R_OUT - d crescente, entao o brilho tem que CAIR com isso)
    into = np.clip(1.0 - (R_OUT - d) / GLOW_IN, 0, 1)
    glow = into ** 1.7 * (d <= R_OUT)

    # segundo halo, mais largo e fraco, para o brilho nao terminar seco
    wide = np.clip(1.0 - (R_OUT - d) / (GLOW_IN * 2.2), 0, 1) ** 2.4 * (d <= R_OUT)

    t = np.clip(line * 1.0 + glow * 0.70 + wide * 0.30, 0, 1)
    t *= (d <= R_OUT + 0.5)

    img = Image.fromarray((t * 255).astype(np.uint8), "L").resize(
        (SIZE, SIZE), Image.LANCZOS)
    a = np.asarray(img, np.float32) / 255.0

    # quantiza para caber na paleta de 256 do L8
    levels = 150   # folga: 210 chegava perto do teto de 256 do L8
    a = np.clip(np.round(a * (levels - 1)) / (levels - 1), 0, 1)

    lo, mid, hi = map(np.array, (C_LOW, C_MID, C_HIGH))
    p = np.clip(a / 0.55, 0, 1)[..., None]
    q = np.clip((a - 0.55) / 0.45, 0, 1)[..., None]
    rgb = lo * (1 - p) + mid * p
    rgb = rgb * (1 - q) + hi * q
    alpha = np.clip(a * 1.25, 0, 1) * 255
    return Image.fromarray(np.dstack([rgb, alpha]).astype(np.uint8), "RGBA")


def main():
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(_os.path.join(_HERE, "preview"), exist_ok=True)

    im = build()
    im.save(f"{OUT}/rim.png")
    n = len(np.unique(np.asarray(im).reshape(-1, 4), axis=0))
    print(f"  rim.png  {SIZE}x{SIZE}  {n} RGBA  {'L8 ok' if n <= 256 else 'ESTOUROU'}")
    print(f"  flash: {(SIZE*SIZE+1024)/1024:.0f} KB em L8_ARGB8888")

    # previa sobre um fundo escuro
    bg = Image.new("RGBA", (SIZE, SIZE), (0, 8, 24, 255))
    bg.alpha_composite(im)
    bg.convert("RGB").save(_os.path.join(_HERE, "preview") + "/rim.png")


if __name__ == "__main__":
    main()
