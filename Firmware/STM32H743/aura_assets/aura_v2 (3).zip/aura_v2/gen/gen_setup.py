#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gera o setup dos widgets - Aura Assistant.

Em vez de voce acertar 18 posicoes a mao no Designer, crie os widgets com os
nomes certos em QUALQUER lugar da tela e deixe este codigo posicionar tudo.

POR QUE ASSIM
Eu poderia escrever direto no arquivo .touchgfx, mas o formato dele muda
entre versoes - e escrever uma chave errada ja custou duas rodadas hoje com
o application.config. Posicionar por codigo e' seguro: se um valor estiver
errado, voce ve na hora e corrige numa linha.

Voce continua podendo mover os widgets no Designer: basta apagar a linha
correspondente do setup gerado. O que o codigo nao posiciona, o Designer
manda.

    python gen_setup.py > setup_widgets.txt
"""

import math

# --- geometria, em coordenadas JA ROTACIONADAS 90 a esquerda -------------
SCREEN = 480
MENU_CX, MENU_CY = 232.0, 239.0
R_ORBIT = 176.0
CAM_D = 3.4
RING_TILT = 46.0

NAMES = ["settings", "tasks", "reminders", "calendar", "chat"]

# tamanhos dos sprites JA ROTACIONADOS (largura e altura trocadas)
SIZES = {
    "board":     (480, 480),
    "rim":       (480, 480),
    "hero":      (200, 200),
    "logo":      (44, 44),
    "wifi":      (22, 22),
    "batt":      (15, 30),
    "ring":      (84, 84),
    "line":      (9, 260),
    "spark":     (26, 26),
    "icon48":    (48, 48),
}

# rotulos girados: o PNG tem 29 de largura e o comprimento do texto na altura
LBL = {"settings": (29, 135), "tasks": (29, 91), "reminders": (29, 157),
       "calendar": (29, 146), "chat": (29, 79)}
MSG = {"hold": (17, 140), "cancelled": (17, 99), "move": (17, 167),
       "nocontent": (17, 144), "back": (17, 205)}


def icon_pose(i, angle=0.0):
    """Mesma matematica do MenuLogic::getIconPose."""
    a = angle + i * (2 * math.pi / 5) + math.pi / 2
    x3, z3 = math.cos(a), math.sin(a)
    k = CAM_D / (CAM_D - z3)
    y = MENU_CY + x3 * R_ORBIT * k
    x = MENU_CX + z3 * RING_TILT
    return int(round(x)), int(round(y))


def topleft(cx, cy, w, h):
    return int(round(cx - w / 2)), int(round(cy - h / 2))


def main():
    print("/* ====================================================================")
    print(" *  Cole no setupScreen(), DEPOIS da chamada a InitialViewBase.")
    print(" *  Gerado por gen_setup.py — posicoes ja rotacionadas 90 a esquerda.")
    print(" *")
    print(" *  Crie os widgets no Designer com estes nomes, em qualquer posicao;")
    print(" *  este codigo coloca cada um no lugar. Para posicionar algum no")
    print(" *  Designer em vez de aqui, apague a linha dele.")
    print(" * ==================================================================== */")
    print()

    print("    /* --- fundo e borda: cobrem a tela inteira --- */")
    print("    board.setXY(0, 0);")
    print("    rimGlow.setXY(0, 0);")
    print("    rimGlow.setAlpha(140);")
    print()

    w, h = SIZES["hero"]
    x, y = topleft(178, 239, w, h)     # centro do logo grande, ja girado
    print("    /* --- logo da tela de espera --- */")
    print(f"    hero.setXY({x}, {y});")
    print()

    print("    /* --- icones do carrossel ---")
    print("       Posicao inicial, no angulo zero. O codigo do handleTickEvent")
    print("       reposiciona a cada frame conforme o carrossel gira. */")
    for i, n in enumerate(NAMES):
        cx, cy = icon_pose(i)
        w, h = SIZES["icon48"]
        x, y = topleft(cx, cy, w, h)
        print(f"    icon{i}.setXY({x}, {y});   /* {n} */")
    print()

    cx, cy = icon_pose(0)
    w, h = SIZES["ring"]
    x, y = topleft(cx, cy, w, h)
    print("    /* --- anel de selecao: acompanha o item selecionado --- */")
    print(f"    selRing.setXY({x}, {y});")
    print("    selRing.setAlpha(0);")
    print()

    w, h = LBL["tasks"]
    x, y = topleft(372, 239, w, h)
    print("    /* --- rotulo da opcao. O codigo troca a imagem e recentra,")
    print("       porque cada palavra tem comprimento diferente. --- */")
    print(f"    lblOption.setXY({x}, {y});")
    print()

    w, h = SIZES["line"]
    x, y = topleft(318, 239, w, h)
    print("    /* --- divisor --- */")
    print(f"    divLine.setXY({x}, {y});")
    w, h = SIZES["spark"]
    x, y = topleft(318, 239, w, h)
    print(f"    divSpark.setXY({x}, {y});")
    print()

    w, h = MSG["hold"]
    x, y = topleft(418, 239, w, h)
    print("    /* --- mensagem de estado --- */")
    print(f"    msgState.setXY({x}, {y});")
    print()

    print("    /* --- barra de status: os tres alinhados no mesmo eixo ---")
    print("       No sistema girado eles ficam empilhados na vertical, do lado")
    print("       esquerdo da tela do Designer. */")
    for name, cx, cy, key in (("logoStatus", 42, 239, "logo"),
                              ("wifiIcon", 42, 294, "wifi"),
                              ("battFrame", 42, 191, "batt")):
        w, h = SIZES[key]
        x, y = topleft(cx, cy, w, h)
        print(f"    {name}.setXY({x}, {y});")
    print()
    print("    /* preenchimento da bateria: cresce na VERTICAL porque a tela")
    print("       esta girada. O applyStatus() ajusta altura e cor. */")
    print("    battFill.setPosition(38, 180, 9, 24);")
    print()

    print("    applyStatus();")


if __name__ == "__main__":
    main()
