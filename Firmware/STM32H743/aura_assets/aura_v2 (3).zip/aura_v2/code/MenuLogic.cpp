#include <gui/common/MenuLogic.hpp>
#include <math.h>

/* --- geometria do carrossel, em coordenadas JA ROTACIONADAS -------------
   No sistema nao girado o carrossel ficava em (240, 232) com o anel
   inclinado no eixo Y. Girar 90 a esquerda troca os eixos: o centro vira
   (232, 239) e a inclinacao passa para o eixo X.                         */
static const float PI_F      = 3.14159265f;
static const float STEP      = 2.0f * PI_F / ML_COUNT;   /* 72 graus       */
static const float MENU_CX   = 232.0f;
static const float MENU_CY   = 239.0f;
static const float R_ORBIT   = 176.0f;
static const float CAM_D     = 3.4f;
static const float RING_TILT = 46.0f;

/* --- interacao --------------------------------------------------------- */
static const float DEAD_ZONE = 0.13f;
static const float SPIN_GAIN = -0.055f;   /* negativo = sentido invertido  */
static const float SNAP_K    = 0.16f;
static const float HYST      = 0.60f;
static const int   DWELL_N   = 72;        /* 1,2 s a 60 Hz                 */
static const float ACT_UP    = 0.55f;
static const float ACT_DOWN  = -0.55f;
static const int   ACT_HOLD  = 12;
static const float VIS_K     = 0.10f;
static const float TILT_MAX  = 26.0f;

static const int16_t ICON_SZ[3] = { 36, 48, 64 };


MenuLogic::MenuLogic()
{
    angle = 0.0f;
    sel = 0;
    dwell = 0;
    armed = true;
    screen = -1;
    msg = 0;
    cancelled = false;
    actHold = 0;
    tilt = 0.0f;
    vis = 0.0f;
    navEvent = 0;
    for (int i = 0; i < ML_COUNT; i++)
    {
        grow[i] = 0.0f;
    }
}

void MenuLogic::open(int idx)
{
    screen = idx;
    navEvent = 1;
    cancelled = false;
    dwell = 0;
    armed = false;
    msg = 90;
}

void MenuLogic::back()
{
    dwell = 0;
    actHold = 0;
    armed = false;
    if (screen >= 0)
    {
        screen = -1;
        navEvent = 2;
        msg = 70;
        cancelled = false;
    }
    else
    {
        cancelled = true;
        msg = 70;
    }
}

void MenuLogic::tick(bool handPresent, float handX, float handY)
{
    vis += ((handPresent ? 1.0f : 0.0f) - vis) * VIS_K;

    if (!handPresent)
    {
        dwell = 0;
        armed = true;
        cancelled = false;
        actHold = 0;
        /* sair do alcance NAO fecha o menu aberto: a pessoa pode estar so
           abaixando a mao. Fechar exige o gesto de voltar.               */
    }
    if (msg > 0)
    {
        msg--;
    }

    /* --- rotacao, com zona morta --- */
    float h = 0.0f;
    if (handPresent && (handX > DEAD_ZONE || handX < -DEAD_ZONE))
    {
        float s = (handX > 0.0f) ? 1.0f : -1.0f;
        float ax = (handX > 0.0f) ? handX : -handX;
        h = s * (ax - DEAD_ZONE) / (1.0f - DEAD_ZONE);
        angle += SPIN_GAIN * h;
        if (h > 0.12f || h < -0.12f)
        {
            armed = true;
        }
    }

    float ah = (h > 0.0f) ? h : -h;
    if (ah < 0.05f)
    {
        float target = STEP * floorf(angle / STEP + 0.5f);
        angle += (target - angle) * SNAP_K;
    }

    /* --- selecao, com histerese --- */
    float raw = -angle / STEP;
    while (raw < 0.0f)
    {
        raw += ML_COUNT;
    }
    raw = fmodf(raw, (float)ML_COUNT);
    int nearIdx = ((int)floorf(raw + 0.5f)) % ML_COUNT;
    if (nearIdx != sel)
    {
        float d = fmodf(raw - sel + ML_COUNT * 1.5f, (float)ML_COUNT)
                  - ML_COUNT * 0.5f;
        if (d < 0.0f) d = -d;
        if (d > HYST)
        {
            sel = nearIdx;
            dwell = 0;
        }
    }

    /* --- dwell --- */
    if (handPresent && ah < 0.05f)
    {
        dwell++;
    }
    else
    {
        dwell = 0;
    }
    if (dwell >= DWELL_N && armed && screen < 0)
    {
        open(sel);
    }

    /* --- eixo vertical: confirmar / cancelar --- */
    float vy = handPresent ? handY : 0.0f;
    tilt += (vy * TILT_MAX - tilt) * 0.18f;

    if (handPresent && (vy > ACT_UP || vy < ACT_DOWN))
    {
        actHold++;
        if (actHold >= ACT_HOLD)
        {
            if (vy > 0.0f)
            {
                if (screen < 0 && armed)
                {
                    open(sel);
                }
            }
            else
            {
                back();
            }
            actHold = 0;
        }
    }
    else
    {
        actHold = 0;
    }

    for (int i = 0; i < ML_COUNT; i++)
    {
        float t = (i == sel) ? 1.0f : 0.0f;
        grow[i] += (t - grow[i]) * 0.35f;
    }
}

int MenuLogic::getDwellStage() const
{
    if (dwell <= 0 || screen >= 0)
    {
        return -1;
    }
    int st = (dwell * 16) / DWELL_N;
    return (st > 15) ? 15 : st;
}

int MenuLogic::getStateMsg() const
{
    if (cancelled && msg > 0) return 1;
    if (!armed) return 2;
    return 0;
}

void MenuLogic::getIconPose(int i, int16_t& cx, int16_t& cy,
                            int16_t& size, uint8_t& alpha) const
{
    float a = angle + i * STEP + PI_F * 0.5f;
    float x3 = cosf(a), z3 = sinf(a);
    float k = CAM_D / (CAM_D - z3);

    /* Eixos trocados em relacao ao sistema nao girado: o que era a
       coordenada horizontal do anel vira a vertical da tela.            */
    float y = MENU_CY + x3 * R_ORBIT * k;
    float x = MENU_CX + z3 * (RING_TILT + tilt);

    cx = (int16_t)x;
    cy = (int16_t)y;

    float depth = (z3 + 1.0f) * 0.5f;
    float szf = ICON_SZ[0]
              + (ICON_SZ[2] - ICON_SZ[0]) * depth * grow[i]
              + (ICON_SZ[1] - ICON_SZ[0]) * depth * (1.0f - grow[i]);
    int slot = 0;
    float bd = 999.0f;
    for (int s = 0; s < 3; s++)
    {
        float d = szf - ICON_SZ[s];
        if (d < 0.0f) d = -d;
        if (d < bd) { bd = d; slot = s; }
    }
    size = ICON_SZ[slot];

    float dd = depth * depth * (0.6f + 0.4f * depth);   /* ~depth^1.4 */
    float v = vis * vis * (0.7f + 0.3f * vis);
    if (screen >= 0)
    {
        v = 0.0f;       /* com um menu aberto o carrossel sai de cena */
    }
    int al = (int)((70.0f + 185.0f * dd) * v);
    alpha = (uint8_t)((al > 255) ? 255 : (al < 0 ? 0 : al));
}
